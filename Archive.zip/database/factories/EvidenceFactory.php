<?php

use Faker\Generator as Faker;

$factory->define(App\Evidence::class, function (Faker $faker) {
    return [
        //
    ];
});
