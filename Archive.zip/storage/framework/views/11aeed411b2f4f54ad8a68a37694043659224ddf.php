<footer class="footer <?php echo $__env->yieldContent('footer-class'); ?>">
    <div class="container">
        <div class="content">
            <div class="row justify-content-around">
                <div class="col-md-4">
                    <h5>PAT MISSION</h5>
                    <p>
                            ● Created to track abuses on the rights of the press.<br>
                            ● Aims to ensure that journalists whose rights have been abused will get a prompt response, once our team has
                            been notified.<br>
                            ● Ensures to have a catalogue of submitted evidence for litigating cases of attacks.
                    </p>
                </div>
                <div class="col-md-4">
                    <h5>Development Team</h5>
                    <p>
                            ● Anna Agboola<br>
                            ● Faruk Nasir
                    </p> 
                </div>

                

                
            </div>
        </div>


        <hr>

        <ul class="float-left">
            <li>
                <a href="<?php echo e(route('reports', ['flag' => true])); ?>">
                    Reports
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('stories')); ?>">
                    Stories
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('about')); ?>">
                    About Us
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('contact')); ?>">
                    Contact Us
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('faq')); ?>">
                    FAQ
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('login')); ?>">
                    Login
                </a>
            </li>
        </ul>

        <div class="copyright float-right">
            Copyright © 
            <script>document.write(new Date().getFullYear())</script>
            Anna and Faruk
        </div>
    </div>
</footer>