<?php $__env->startSection('admin-nav-title', 'Edit Story'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Story has been saved successfully.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <form id="" class="form-horizontal" action="<?php echo e(route('adminUpdateStory')); ?>" 
      method="POST" novalidate="novalidate" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="card ">
        <div class="card-header card-header-default card-header-text">
          <div class="card-text">
            <h4 class="card-title"><?php echo e($story->title); ?></h4>
          </div>
        </div>
        <div class="card-body">

            <div class="form-group my-5">
                <label for="">
                Author
                </label>
                <input name="author" value="<?php echo e($story->author); ?>" type="text" class="form-control" placeholder="Author">
            </div>

            <div class="form-group my-5">
                <label for="">
                Story Title
                </label>
                <input name="title" value="<?php echo e($story->title); ?>" type="text" class="form-control" placeholder="Title">
            </div>

            <div class="form-group my-5">
                <label for="">
                Story
                </label><br><br>
                <textarea name="story" class="form-control" id="story" rows="6"><?php echo e($story->story); ?></textarea>
            </div>

            <div class="form-group my-5">
                <label for="">
                Tags
                </label>
                <input type="text" value="<?php echo e($story->tags); ?>" name="tags" class="form-control tagsinput" 
                data-role="tagsinput" data-color="danger">
            </div>

            <?php if($story->status_id == 1): ?>
            <div class="form-group-my-5">
                <label for="">
                    Status
                </label>
                <select class="form-control selectpicker" name="status_id" id="status_id">
                    <option value="1" <?php if($story->status_id == 1): ?> <?php echo e("selected"); ?> <?php endif; ?>>
                        Save As Draft
                    </option>
                    <option value="2" <?php if($story->status_id == 2): ?> <?php echo e("selected"); ?> <?php endif; ?>>
                        Submit For Approval
                    </option>
                </select>
            </div>
            <?php else: ?>
            <div class="form-group my-5">
                <label for="">
                    Status
                </label>
                <input name="status_id" value="<?php echo e(App\Status::findOrFail($story->status_id)->name); ?>" type="text" 
                    class="form-control" placeholder="status" disabled>
            </div>
            <?php endif; ?>

            <input type="hidden" name="id" value="<?php echo e($story->id); ?>" />
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">
            <i class="material-icons">add</i>
            Submit Story
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
      <!-- classic ckeditor init -->
      ClassicEditor
        .create( document.querySelector( '#story' ) )
        .then( editor => {
            //console.log( editor );
        } )
        .catch( error => {
            //console.error( error );
        } );
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>