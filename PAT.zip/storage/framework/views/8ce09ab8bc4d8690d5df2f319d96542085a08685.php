<?php $__env->startSection('content'); ?>
  
    

<div class="page-header header-filter header-small" data-parallax="true" 
  style="background-image: url('<?php echo e(asset('img/bg9.jpg')); ?>');">
  <div class="container">
    <div class="row">
      <div class="col-md-8 ml-auto mr-auto text-center">
        <h1 class="title">About PAT</h1>
        <h4>Take A Look Behind The Scenes</h4>
      </div>
    </div>
  </div>
</div>
<div class="main main-raised">
  <div class="container">


    <div class="about-description text-center pt-3">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto">
          <h5 class="description">
            In 2017, Premium Times Center 
            for Investigative Journalism (PTCIJ) 
            saw the need to create an independent 
            media that can allow for free public 
            participation in the development of the 
            nation, as well as build the capacity 
            of journalists on physical, psychological 
            and digital safety
          </h5>
        </div>
      </div>
    </div>

    
    <div class="about-services features-2">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h2 class="title">How it works:</h2>
          <h5 class="description">
              Press Attack Nigeria as the name implies, is a platform to track and report attacks on the press. 
              The platform will provide a map of threats and attack on the press thus providing data for periodic 
              review and also serve as advocacy tool for Press Freedom in the wider Nigerian society.
              <br>
              <br>
              The tracker is the innovative outcome of Premium Times Centre for Investigative Journalism with the 
              support of Free Press Unlimited.
          </h5>
        </div>
      </div>
      
    </div>
    <div class="about-office">
      <div class="row text-center">
        <div class="col-md-8 ml-auto mr-auto">
          <h2 class="title">How Can I Use The Tracker?</h2>
          <h4 class="description">
            This tutorial will walk you thorugh how to submit a report on PAT.
          </h4>
        </div>
      </div>
      <div class="row ">
          <div class="col-md-8 ml-auto mr-auto">
              <iframe width="100%" height="400" src="https://www.youtube-nocookie.com/embed/iSgUMPHQEWw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
      </div>
    </div>
    <hr>
    
            
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>