<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Report has been updated successfully.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <form id="" class="form-horizontal" action="<?php echo e(route('adminUpdateReport')); ?>" 
        method="POST" novalidate="novalidate">
      <?php echo csrf_field(); ?>
      <div class="card ">
        <div class="card-header card-header-default card-header-text">
            <div class="card-text">
                <h4 class="card-title">
                    <?php echo e($report->title); ?>

                </h4>
            </div>
        </div>
        <div class="card-body">

            <div class="row my-5">
                <div class="col-md-8">
                <div class="form-group">
                    <label for="report-description">
                        Report Title
                    </label>
                    <input name="title" type="text" class="form-control" placeholder="Title" value="<?php echo e($report->title); ?>">
                </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <select name="report_type_id" class="form-control selectpicker" data-style="" id="report-type">
                            <option disabled>Report Type</option>
                            <?php
                                $reportTypes = App\ReportType::all();
                            ?>
                            <?php for($i = 0; $i < count($reportTypes); $i++): ?>
                                <?php
                                    $reportType = $reportTypes[$i];
                                ?>
                                <option value="<?php echo e($reportType->id); ?>" <?php if($report->report_type_id == $reportType->id): ?> <?php echo e("selected"); ?> <?php endif; ?>>
                                    <?php echo e($reportType->name); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-group my-5">
                <label for="report-description">
                    Report Description
                </label><br><br>
                <textarea name="description" class="form-control" id="report-description" rows="6">
                    <?php echo e($report->description); ?>

                </textarea>
            </div>

            <div class="col-md-6">
                    <label for="report-description">
                        Location (state)
                      </label><br>
                  <select name="state_id" class="form-control selectpicker" data-style="" id="state" style="max-height: 50px">
                      <?php
                          $states = App\State::all();
                      ?>
                      <?php for($i = 0; $i < count($states); $i++): ?>
                          <?php
                              $state = $states[$i];
                          ?>
                          <option value="<?php echo e($state->id); ?>">
                          <?php echo e($state->name); ?>

                          </option>
                      <?php endfor; ?>
                  </select>
              <span class="material-input"></span>
          </div>

            <div class="form-group my-5">
                <label for="">
                    Victim
                </label>
                <input type="text" name="victim" class="form-control" placeholder="Victim" value="<?php echo e($report->victim); ?>">
            </div>

            <div class="form-group my-5">
                <label for="">
                    Affiliation
                </label>
                <input type="text" name="affiliation" class="form-control" placeholder="Affiliation" value="<?php echo e($report->affiliation); ?>">
            </div>

            <div class="form-group my-5">
                <label for="">
                    Assailant
                </label>
                <input type="text" name="assailant" class="form-control" placeholder="Assailant" value="<?php echo e($report->assailant); ?>">
            </div>

            <!-- input with datetimepicker -->
            <div class="form-group my-5">
                <label class="">
                    Incident Date
                </label>
                <input name="date" type="text" class="form-control datetimepicker" value="<?php echo e($report->date); ?>"/>
            </div>

            

            <input name="id" type="hidden" value="<?php echo e($report->id); ?>">          
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">
            <i class="material-icons">add</i>
                Submit Report
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
        <!-- javascript for init -->
        $('.datetimepicker').datetimepicker({
            icons: {
                time: "fa fa-clock-o",
                date: "fa fa-calendar",
                up: "fa fa-chevron-up",
                down: "fa fa-chevron-down",
                previous: 'fa fa-chevron-left',
                next: 'fa fa-chevron-right',
                today: 'fa fa-screenshot',
                clear: 'fa fa-trash',
                close: 'fa fa-remove'
            }
        });

        <!-- classic ckeditor init -->
        ClassicEditor
            .create( document.querySelector( '#report-description' ) )
            .then( editor => {
                //console.log( editor );
            })
            .catch( error => {
                //console.error( error );
            });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>