
        <div class="col-sm-6 col-lg-3">
            <div class="card">
                <div class="card-header card-header-icon card-header-info">
                  <div class="card-icon">
                    <i class="material-icons">language</i>
                  </div>
                </div>
                <div class="card-body">
                    <h4 class="card-title">New Stories</h4>
                        since xxx date
                </div>
            </div>
        </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card">
            <div class="card-header card-header-icon card-header-info">
                <div class="card-icon">
                <i class="material-icons">language</i>
                </div>
            </div>
            <div class="card-body">
                <h4 class="card-title">Unapproved Stories</h4>
                    Total number
            </div>
        </div>
    </div>