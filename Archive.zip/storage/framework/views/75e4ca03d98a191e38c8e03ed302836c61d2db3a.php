<?php $__env->startSection('admin-nav-title', 'Update Report'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        Report has been updated successfully.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>


    <!-- Reports Metrics  -->
    <?php $__env->startComponent('components.admin.report.metrics', ['report' => $report]); ?>
        
    <?php echo $__env->renderComponent(); ?>


    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">
                            assignment
                        </i>
                    </div>
                    <h4 class="card-title">
                        <?php echo e($report->title); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <!-- Toolbar -->
                    <div class="toolbar">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $report)): ?>
                        <a href="<?php echo e(route('admin/report/edit', ['id'=>$report->id])); ?>" 
                            class="btn btn-info btn-sm">
                            <i class="material-icons">edit</i>
                            Edit
                        </a>
                        <a href="<?php echo e(route('addEvidence', ['report' => $report->id])); ?>" 
                            class="btn btn-info btn-sm">
                            <i class="material-icons">create</i>
                            Upload Evidence
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('writeStory', ['reportId'=>$report->id])); ?>" 
                            class="btn btn-info btn-sm">
                            <i class="material-icons">create</i>
                            Write Story
                        </a>
                    </div>
                    <hr>

                    <!-- Report Description -->
                    <div class="content my-5">
                        <?php echo $report->description; ?>

                    </div>
                    <hr>

                    <!-- Evidences -->
                    <?php $__env->startComponent('components.admin.report.evidence', ['report'=>$report]); ?>
                        
                    <?php echo $__env->renderComponent(); ?>
                    
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <!-- Report Details -->
            <?php $__env->startComponent('components.admin.report.details', ['report'=>$report]); ?>
                
            <?php echo $__env->renderComponent(); ?>

            <!-- Submitted By -->
            <div class="card card-testimonial">
                <div class="icon">
                    <i class="material-icons">person</i>
                </div>
                <div class="card-body">
                    <h5 class="card-description">
                        Reported By
                    </h5>
                </div>
                <div class="card-footer">
                    <h4 class="card-title">
                        <?php echo e($report->user->name); ?>

                    </h4>
                </div>
            </div>
            <br><br>


        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>