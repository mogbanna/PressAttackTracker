<?php $__env->startSection('admin-nav-title', 'My Submissions'); ?>

<?php $__env->startSection('content'); ?>

<?php

$user = Auth::user();
$userReports = App\Report::where('user_id', $user->id)->get();
$userStories = App\Story::where('user_id', $user->id)->get();

?>

<div class="row">
    <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary card-header-icon">
                    <div class="card-icon">
                    <i class="material-icons">
                        description
                    </i>
                    </div>
                    <h4 class="card-title">
                    My Reports
                    </h4>
                </div>
            <div class="card-body">
                <?php if($userReports->isEmpty()): ?>
                    <h4 class="text-center">You have not submit any reports yet.</h4>
                <?php else: ?>
                    <?php $__env->startComponent('components.admin.user.reports', ['reports' => $userReports]); ?>
    
                    <?php echo $__env->renderComponent(); ?>
                <?php endif; ?>
        
            </div>
        </div>
<br>
        <div class="card">
                <div class="card-header card-header-info card-header-icon">
                    <div class="card-icon">
                    <i class="material-icons">
                        insert_comment
                    </i>
                    </div>
                    <h4 class="card-title">
                    My Stories
                    </h4>
                </div>
            <div class="card-body">
                <?php if($userStories->isEmpty()): ?>
                    <h4 class="text-center">You have not submit any reports yet.</h4>
                <?php else: ?>
                    <?php $__env->startComponent('components.admin.user.stories', ['stories' => $userStories]); ?>
    
                    <?php echo $__env->renderComponent(); ?>
                <?php endif; ?>
        
            </div>
        </div>

    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>