<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('storage/'.$story->thumbnail)); ?>');">
    <div class="container">
        <div class="row justify-content-around">
            <?php $__env->startComponent('components.story.metrics', ['story'=>$story]); ?>
                
            <?php echo $__env->renderComponent(); ?>
        </div>
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h1 class="title"><?php echo e($story->title); ?></h1>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">

      <div class="card card-nav-tabs">
      <h4 class="card-header card-header-info">STORY</h4>
      <div class="card-body">
       <div class="section section-text">
        <div class="row">
          <div class="col-8">
            <div class="blockquote undefined">
              <p>
                <?php echo $story->story; ?>

              </p>
            </div>
          </div>
          <div class="col">
            <?php $__env->startComponent('components.story.details', ['story' => $story]); ?>
                
            <?php echo $__env->renderComponent(); ?>
          </div>
        </div>
      </div>
    <div class="section section-gray">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="title text-center">Other Stories</h2>
            <br>
            <div class="row">
              <?php $__env->startComponent('components.story.stories'); ?>
                  
              <?php echo $__env->renderComponent(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>