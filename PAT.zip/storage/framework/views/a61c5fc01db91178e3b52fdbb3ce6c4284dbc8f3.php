<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('img/bg5.jpg')); ?>');">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h1 class="title">Report Title?</h1>
          <h4>A short description of this post?</h4>
          <br>
          
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">
    <div class="container">
      <div class="section section-text">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h3 class="title">Another Title about nothing really..</h3>
            <p>I'd say this paragraph is useless, but then you'd be questioning ->
              <br>
              <br> The usefulness of this paragraph as well....</p>
            <div class="blockquote undefined">
              <p>
                &#x201C;But to really bust your head, lets add more useless paragraph space :)&#x201D;
              </p>
              <small>
                I Suggest, Some-Name-Here
              </small>
            </div>
          </div>
          <div class="section col-md-10 ml-auto mr-auto">
            <div class="row">
              <div class="col-md-4">
                <img class="img-raised rounded img-fluid" alt="Raised Image" src="<?php echo e(asset('img/examples/blog4.jpg')); ?>">
              </div>
              <div class="col-md-4">
                <img class="img-raised rounded img-fluid" alt="Raised Image" src="<?php echo e(asset('img/examples/blog3.jpg')); ?>">
              </div>
              <div class="col-md-4">
                <img class="img-raised rounded img-fluid" alt="Raised Image" src="<?php echo e(asset('img/examples/blog1.jpg')); ?>">
              </div>
            </div>
          </div>
          <div class="col-md-8 ml-auto mr-auto">
            <h3 class="title">Now the Juicy Story Title (again?):</h3>
            <p>We are here to make life better. And now I look and look around and there&#x2019;s so many Kanyes I&apos;ve been trying to figure out the bed design for the master bedroom at our Hidden Hills compound... and thank you for turning my personal jean jacket into a couture piece.
              <br> I speak yell scream directly at the old guard on behalf of the future. daytime All respect prayers and love to Phife&#x2019;s family Thank you for so much inspiration. </p>
            <p> Thank you Anna for the invite thank you to the whole Vogue team And I love you like Kanye loves Kanye Pand Pand Panda I&apos;ve been trying to figure out the bed design for the master bedroom at our Hidden Hills compound...The Pablo pop up was almost a pop up of influence. All respect prayers and love to Phife&#x2019;s family Thank you for so much inspiration daytime I love this new Ferg album! The Life of Pablo is now available for purchase I have a dream. Thank you to everybody who made The Life of Pablo the number 1 album in the world! I&apos;m so proud of the nr #1 song in the country. Panda! Good music 2016!</p>
            <p> I love this new Ferg album! The Life of Pablo is now available for purchase I have a dream. Thank you to everybody who made The Life of Pablo the number 1 album in the world! I&apos;m so proud of the nr #1 song in the country. Panda! Good music 2016!</p>
          </div>
        </div>
      </div>
      <div class="section section-blog-info">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <div class="row">
              <div class="col-md-6">
                <div class="blog-tags">
                  Tags:
                  <span class="badge badge-primary badge-pill">Photography</span>
                  <span class="badge badge-primary badge-pill">Stories</span>
                  <span class="badge badge-primary badge-pill">Castle</span>
                </div>
              </div>
              <div class="col-md-6">
                <a href="#pablo" class="btn btn-twitter btn-round float-right">
                  <i class="fa fa-twitter"></i> 910
                </a>
                <a href="#pablo" class="btn btn-facebook btn-round float-right">
                  <i class="fa fa-facebook-square"></i> 872
                </a>
              </div>
            </div>
            <hr>
            
            <!-- end media-post -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="section">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="title text-center">Stories Related to this Report:</h2>
          <br>
          <div class="row">
            <div class="col-md-4">
              <div class="card card-blog">
                <div class="card-header card-header-image">
                  <a href="#pablo">
                    <img class="img img-raised" src="<?php echo e(asset('img/examples/blog6.jpg')); ?>">
                  </a>
                </div>
                <div class="card-body">
                  <h6 class="category text-info">Enterprise</h6>
                  <h4 class="card-title">
                    <a href="#pablo">Autodesk looks to future of 3D printing with Project Escher</a>
                  </h4>
                  <p class="card-description">
                    Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                    <a href="#pablo"> Read More </a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card card-blog">
                <div class="card-header card-header-image">
                  <a href="#pablo">
                    <img class="img img-raised" src="<?php echo e(asset('img/examples/blog8.jpg')); ?>">
                  </a>
                </div>
                <div class="card-body">
                  <h6 class="category text-success">
                    Startups
                  </h6>
                  <h4 class="card-title">
                    <a href="#pablo">Lyft launching cross-platform service this week</a>
                  </h4>
                  <p class="card-description">
                    Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                    <a href="#pablo"> Read More </a>
                  </p>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card card-blog">
                <div class="card-header card-header-image">
                  <a href="#pablo">
                    <img class="img img-raised" src="<?php echo e(asset('img/examples/blog7.jpg')); ?>">
                  </a>
                </div>
                <div class="card-body">
                  <h6 class="category text-danger">
                    <i class="material-icons">trending_up</i> Enterprise
                  </h6>
                  <h4 class="card-title">
                    <a href="#pablo">6 insights into the French Fashion landscape</a>
                  </h4>
                  <p class="card-description">
                    Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                    <a href="#pablo"> Read More </a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>