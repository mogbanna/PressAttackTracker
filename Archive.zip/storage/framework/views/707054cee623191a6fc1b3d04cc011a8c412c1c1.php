<?php $__env->startSection('admin-nav-title', 'Upload Evidence'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Evidence has been uploaded successfully.
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
    <form id="" class="form-horizontal" action="<?php echo e(route('adminAddEvidence')); ?>" 
      method="POST" novalidate="novalidate" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="card ">
        <div class="card-header card-header-default card-header-text">
          <div class="card-text">
            <h4 class="card-title"><?php echo e($report->title); ?></h4>
          </div>
        </div>
        <div class="card-body">

            

            <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                <label for="">
                    Evidence Upload(max: 2mb)
                    <small>
                        (jpeg,bmp,png,pdf,txt,html,jpg,doc,docx,xls,csv,tsv)
                    </small>
                </label><br>
                <input type="file" name="file" class="form-control">
            </div>

            <input type="hidden" name="report_id" value="<?php echo e($report->id); ?>" />
        </div>
        <div class="card-footer">
          <button type="submit" class="btn btn-info">
            <i class="material-icons">add</i>
            Upload
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>