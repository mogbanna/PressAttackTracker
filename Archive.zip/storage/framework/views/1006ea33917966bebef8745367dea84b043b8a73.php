<?php $__env->startSection('content'); ?>

<?php
    $states = App\State::withcount('reports')->get();
?>

<div class="row">
        <div class="col-md-12">
          <div class="card ">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
                <i class="material-icons"></i>
              </div>
              <h4 class="card-title">Submitted Reports by State</h4>
            </div>
            <div class="card-body ">
              <div class="row">
                 <div class="col-md-6">
                    <table id="statesTable" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>State</th>
                                <th># of Reports</th>
                                <th>% of Reports</th>
                                <th>Last Submitted Report</th>
                            </tr>
                        </thead>
                        <tbody> 
                            <?php for($i = 0; $i < count($states); $i++): ?>
            
                                        <?php
                                            $state = $states[$i];
                                            $count = $state->reports_count;  
                                            $percent = sprintf("%.2f%%", ($count / App\Report::count()) * 100);
                                            $findDate = App\Report::select('created_at')->where('state_id', $state->id)->latest()->first();
                                        

                                            if(empty($findDate)){
                                                $lastDate = 'N/A';
                                                
                    
                                            }else{
                                                $lastDate = $findDate->created_at->format('d/m/Y');
                                            }

                                        ?>
                        
                                        <tr>
                                            <td><?php echo e($state->name); ?></td>
                                            <td><?php echo e($count); ?></td>
                                            <td><?php echo e($percent); ?></td>
                                            <td><?php echo e($lastDate); ?></td>
                                        </tr>
                                 <?php endfor; ?>
                                </tbody>
                            <tfoot>
                                <tr>
                                        <th>State</th>
                                        <th># of Reports</th>
                                        <th>% of Reports</th>
                                        <th>Last Submitted Report</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="col-md-6 ml-auto mr-auto">
                    <div id="mapsvg"></div>
                    </div>
                    </div>
                    </div>
                    </div>
                  </div>
                </div>
                  <div class="row">
                      <div class="col col-md-6">
                  <?php $__env->startComponent('components.admin.dashboard.new_submittions'); ?>
    
                  <?php echo $__env->renderComponent(); ?>

                  
                    <?php $__env->startComponent('components.admin.dashboard.report_graph'); ?>
                          
                    <?php echo $__env->renderComponent(); ?>
                 
                    
                        </div>
                      <div class="col col-md-6">

            <?php if(Auth::user()->hasRole('administrator')): ?>
                  <?php $__env->startComponent('components.admin.dashboard.unverified_submittions'); ?>
                      
                  <?php echo $__env->renderComponent(); ?>
            <?php endif; ?>
                      <?php $__env->startComponent('components.admin.dashboard.top_stats'); ?>
                          
                      <?php echo $__env->renderComponent(); ?>
                      
                    </div>
                  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

// let states = <?php echo App\State::with('reports')->withCount('reports')->get() ?>;
// console.log(states);
// let regions = [];
// for (let i = 0; i < states.length; i++) {
//     var name = states[i].name;
//     var numReports = states[i].reports_count;
//     var region = nonBelievers.getRegions(name, numReports);
//     regions.push(region);
// }

$(document).ready(function() {
    $('#statesTable').DataTable( {
        "lengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
        responsive: true,
        language: {
              search: "_INPUT_",
              searchPlaceholder: "Search records",
            }
    });

    let byMonth = <?php echo App\Report::all()->groupBy(function($date) {
        return Carbon\Carbon::parse($date->created_at)->format('m');
    }); ?>;

    let byReportType = <?php echo App\ReportType::with('reports')->get() ?>;

    nonBelievers.initCharts(byMonth, byReportType);

} );


let svgM = $('#mapsvg').mapSvg({source: '<?php echo e(asset('/img/svg-map/nigeria.svg')); ?>',
                    responsive: true,
                    loadingText: "Map is loading...",
                    colors: {
                        background: transparent,
                        base: '#5ab15e',
                        hover: '#ffffff',
                        stroke: '#000000'
                    },
                    tooltips: {
                        mode:"title"
                    },
                    guage: {
                        on: true,
                        labels: {
                            low: 'low',
                            high: 'high'
                        },
                        colors: {
                            low: '#550000',
                            high: '#ee0000'
                        }
                    }
                  

});


    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>