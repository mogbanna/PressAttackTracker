<?php
    $relatedStories = App\Story::inRandomOrder()->offset(0)->limit(3)->get();
?>

<?php for($i = 0; $i < count($relatedStories); $i++): ?>
    <?php
        $relatedStory = $relatedStories[$i];

        $description = $relatedStory->story;
          $len = strLen($description);
          
          if($len > 100){
            $description = substr($relatedStory->story, 0, 100).'...' ;
          }
    ?>
<div class="col-md-4">
    <div class="card card-blog">
        <div class="card-header card-header-image">
        <a href="<?php echo e(route('story', [$relatedStory->id])); ?>">
            <img class="img img-raised" src="<?php echo e(asset('storage/'.$relatedStory->thumbnail)); ?>">
        </a>
        </div>
        <div class="card-body">
        <h4 class="card-title">
            <a href="<?php echo e(route('story', [$relatedStory->id])); ?>"><?php echo e($relatedStory->title); ?></a>
        </h4>
        <p class="card-description">
            <?php echo $description; ?>

            <a class="text-info" href="<?php echo e(route('story', [$relatedStory->id])); ?>"> Read More </a>
        </p>
        </div>
    </div>
</div>
<?php endfor; ?>