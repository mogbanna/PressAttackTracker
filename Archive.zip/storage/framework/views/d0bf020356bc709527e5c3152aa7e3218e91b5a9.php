<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>


<?php $__env->startSection('content'); ?>
<div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('img/bg10.jpg')); ?>');">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h2 class="title">A Whole Lotta Stories</h2>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">
    <div class="container">
        <div class="section">
        
        
      <div class="section">
        <div class="row justify-content-center">
            <nav aria-label="page navigation">
                <ul class="pagination ">
                  <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                  </li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item">
                    <a class="page-link" href="#">Next</a>
                  </li>
                </ul>
              </nav>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="card card-plain card-blog">
              <div class="card-header card-header-image">
                <a href="#pablo">
                  <img class="img img-raised" src="<?php echo e(asset('img/bg5.jpg')); ?>">
                </a>
              </div>
              <div class="card-body">
                <h6 class="card-category text-info">Enterprise</h6>
                <h4 class="card-title">
                  <a href="#pablo">Autodesk looks to future of 3D printing with Project Escher</a>
                </h4>
                <p class="card-description">
                  Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                  <a href="#pablo"> Read More </a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card card-plain card-blog">
              <div class="card-header card-header-image">
                <a href="#pablo">
                  <img class="img img-raised" src="<?php echo e(asset('img/examples/blog5.jpg')); ?>">
                </a>
              </div>
              <div class="card-body">
                <h6 class="card-category text-success">
                  Startups
                </h6>
                <h4 class="card-title">
                  <a href="#pablo">Lyft launching cross-platform service this week</a>
                </h4>
                <p class="card-description">
                  Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                  <a href="#pablo"> Read More </a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card card-plain card-blog">
              <div class="card-header card-header-image">
                <a href="#pablo">
                  <img class="img img-raised" src="<?php echo e(asset('img/examples/blog6.jpg')); ?>">
                </a>
              </div>
              <div class="card-body">
                <h6 class="card-category text-danger">
                  <i class="material-icons">trending_up</i> Enterprise
                </h6>
                <h4 class="card-title">
                  <a href="#pablo">6 insights into the French Fashion landscape</a>
                </h4>
                <p class="card-description">
                  Like so many organizations these days, Autodesk is a company in transition. It was until recently a traditional boxed software company selling licenses.
                  <a href="#pablo"> Read More </a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="row justify-content-center">
                <nav aria-label="page navigation">
                    <ul class="pagination ">
                        <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                        </li>
                    </ul>
                    </nav>
            </div>
      </div>
    </div>
    </div>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>