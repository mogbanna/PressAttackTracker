<?php $__env->startSection('admin-nav-title', 'User Profile'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">


        <!-- -->
        <div class="card">
            <div class="card-header card-header-icon card-header-rose">
                <div class="card-icon">
                <i class="material-icons">perm_identity</i>
                </div>
                <h4 class="card-title">Profile
                <small class="category"></small>
                </h4>
            </div>
            <div class="card-body">
                <div class="m-5">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Email address</label>
                                <input type="email" value="<?php echo e($user->email); ?>" class="form-control" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Full Name</label>
                                <input type="text" value="<?php echo e($user->name); ?>" class="form-control" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>


        <div class="card">
            <div class="card-header card-header-icon card-header-rose">
                <div class="card-icon">
                <i class="material-icons">perm_identity</i>
                </div>
                <h4 class="card-title">Password -
                <small class="category">Change Your Password</small>
                </h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('changePassword')); ?>" method="POST" class="m-5">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        Password has been changed successfully.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">New Password</label>
                                <input value="<?php echo e(old('password')); ?>" type="password" name="password" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="bmd-label-floating">Confirm Password</label>
                                <input value="<?php echo e(old('password_confirmation')); ?>" type="password" name="password_confirmation" class="form-control" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-info pull-right">
                        Change Password
                    </button>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>


    </div>
    <div class="col-md-4">
        <div class="card card-profile">
            <div class="card-avatar">
                <a href="#pablo">
                <img class="img" src="<?php echo e(asset('img/default-avatar.png')); ?>" />
                </a>
            </div>
            <div class="card-body">
                <h6 class="card-category text-gray">
                    <?php
                        $roles = $user->roles()->select('name')->get();
                    ?>
                    <?php for($i = 0; $i < count($roles); $i++): ?>
                        <?php
                            $role = $roles[$i];
                        ?>
                        <?php echo e($role->name.' '); ?>

                    <?php endfor; ?>
                </h6>
                <h4 class="card-title"><?php echo e($user->name); ?></h4>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>