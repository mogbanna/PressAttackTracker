<h1>YOU'VE GOT MAIL! :) </h1>

<h3>From: {{ $name }}</h3>

<h4>Message:</h4>
<div>
    <p>
        {{ $message_body }}
    </p>
</div>

<h4>Contact Info</h4>
<ul>
    <li>Email: {{ $email }}</li>
    <li>Phone Number: {{ $phone }}</li>
</ul>