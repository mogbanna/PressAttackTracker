<h1>YOU'VE GOT MAIL! :) </h1>

<h3>From: <?php echo e($name); ?></h3>

<h4>Message:</h4>
<div>
    <p>
        <?php echo e($message_body); ?>

    </p>
</div>

<h4>Contact Info</h4>
<ul>
    <li>Email: <?php echo e($email); ?></li>
    <li>Phone Number: <?php echo e($phone); ?></li>
</ul>