<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>


<?php $__env->startSection('content'); ?>

<div class="page-header header-filter header-small" data-parallax="true" style="background-image: url('<?php echo e(asset('img/bg10.jpg')); ?>');">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto text-center">
          <h2 class="title">What the Journalists are Saying</h2>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">
    <div class="container">
      <div class="section">
        <div class="row justify-content-center">
               
        <?php echo e($stories->links()); ?>

        <div class="row">
          <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
              $description = $story->story;
          $len = strLen($description);
          
          if($len > 100){
            $description = substr($story->story, 0, 100).'...' ;

          }
          ?>
              
          <div class="col-md-4">
            <div class="card card-blog">
              <div class="card-header card-header-image">
              <a href="<?php echo e(route('story', ['id' => $story->id])); ?>">
                  <img class="img img-raised" src="<?php echo e(asset('storage/'.$story->thumbnail)); ?>">
              </a>
              </div>
              <div class="card-body">
              <h4 class="card-title">
                  <a href="<?php echo e(route('story', ['id' => $story->id])); ?>"><?php echo e($story->title); ?></a>
              </h4>
              <p class="card-description">
                  <?php echo $description; ?>

                  <a class="text-info" href="<?php echo e(route('story', ['$id' => $story->id])); ?>"> Read More </a>
              </p>
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo e($stories->links()); ?>

        
      </div>
    </div>
    </div>
    </div>
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>