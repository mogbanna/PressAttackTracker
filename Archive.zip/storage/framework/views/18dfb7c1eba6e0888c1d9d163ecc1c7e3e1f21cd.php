<?php
    $report = App\Report::select()->orderBY('views','desc')->first();
    $story = App\Story::select()->orderBY('views','desc')->first();
    $user = App\User::withCount('stories')->orderBY('stories_count', 'desc')->first();

    $storyDesc = $story->story;
          $len = strLen($storyDesc);
          
          if($len > 100){
            $storyDesc = substr($story->story, 0, 100).'...' ;
          }

    $reportDesc = $report->description;
      $len = strLen($reportDesc);
      
      if($len > 100){
        $reportDesc = substr($report->description, 0, 100).'...' ;
      }

?>

        <ul class="timeline timeline-simple">
          <li class="timeline-inverted">
            <div class="timeline-badge danger">
              <i class="material-icons">description</i>
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <span class="badge badge-pill badge-rose">Trending Report</span>
              </div>
              <div class="timeline-body">
                  <h4 class="card-title text-center"><b><?php echo e($report->title); ?> </b></h4>
              <p><?php echo $reportDesc; ?></p>
              <br>
              <b>Victim:</b> <?php echo e($report->victim); ?>, 
              <b>Assailant:</b> <?php echo e($report->assailant); ?>


              <hr>
              <h6 class="pull-left">
                  <i class="ti-time"></i> <?php echo e($report->views); ?> views
                </h6>
              <div class="dropdown pull-right">
                  <button type="button" class="btn btn-round btn-info dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu dropdown-menu-right" role="menu">
                    <li>
                      <a href="<?php echo e(route('showReport', ['id'=>$report->id])); ?>">View</a>
                    </li>
                    <li>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $report)): ?>
                      <a href="<?php echo e(route('admin/report/edit', ['id'=>$report->id])); ?>">Edit</a>
                      <?php endif; ?>
                    </li>
                  </ul>
                </div>
              </div>
              
            </div>
          </li>
          <li class="timeline-inverted">
            <div class="timeline-badge info">
              <i class="material-icons">insert_comment</i>
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <span class="badge badge-pill badge-info align-content-center">Trending Story</span>
              </div>
              <div class="timeline-body">
                <h4 class="card-title"><b><?php echo e($story->title); ?> </b></h4>
                <p><?php echo $storyDesc; ?></p>
                <hr>
                <h6 class="pull-left">
                    <i class="ti-time"></i> <?php echo e($story->views); ?> views
                </h6>
                <div class="dropdown pull-right">
                    <button type="button" class="btn btn-round btn-info dropdown-toggle" data-toggle="dropdown">
                      <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-right" role="menu">
                      <li>
                        <a href="<?php echo e(route('showReport', ['id'=>$report->id])); ?>">View</a>
                      </li>
                      <li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $report)): ?>
                        <a href="<?php echo e(route('admin/report/edit', ['id'=>$report->id])); ?>">Edit</a>
                        <?php endif; ?>
                      </li>
                    </ul>
                  </div>
              </div>
            </div>
          </li>
          <li class="timeline-inverted">
            <div class="timeline-badge danger">
              <i class="material-icons">face</i>
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <span class="badge badge-pill badge-danger">Trending Journalist</span>
              </div>
              <div class="timeline-body">
                  <h4 class="card-title"><b><?php echo e($user->name); ?> </b></h4> 
                  <hr>
                  <h6 class="pull-left">
                  <?php echo e($user->stories_count); ?> total stories
                  </h6>
              </div>
            </div>
          </li>
        </ul>