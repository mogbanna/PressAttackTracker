<?php

use Faker\Generator as Faker;

$factory->define(App\ReportType::class, function (Faker $faker) {
    return [
        //
    ];
});
