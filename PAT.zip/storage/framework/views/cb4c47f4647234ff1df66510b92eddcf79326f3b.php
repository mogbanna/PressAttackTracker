<nav class="<?php echo $__env->yieldContent('nav-class'); ?>" 
     id="sectionsNav">
     
    <div class="container">
        <div class="navbar-translate">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Press Attack Tracker')); ?> 
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" 
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="material-icons">description</i>
                        Reports
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="<?php echo e(route('reports', ['flag' => true])); ?>">Browse Reports</a>
                        <a class="dropdown-item" href="<?php echo e(route('addReportForm')); ?>">Submit Report</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('stories')); ?>" class="nav-link">
                        <i class="material-icons">insert_comment</i>
                        Stories
                    </a>
                </li>
                <li class="nav-item">
                <a href="<?php echo e(route('about')); ?>" class="nav-link">
                        <i class="material-icons">live_help</i>
                        About
                    </a>
                </li>
                <li class="nav-item">
                    <a href="https://isupportfreepress.pressattack.ng/" class="nav-link" target="_blank">
                        <i class="material-icons">record_voice_over</i>
                        #iSupportFreePress
                    </a>
                </li>
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">
                            <i class="material-icons">person</i>
                            <?php echo e(__('Login')); ?>

                        </a>
                    </li>
                    <li class="nav-item">
                        <?php if(Route::has('register')): ?>
                        <a class="nav-link" href="<?php echo e(route('register')); ?>">
                            <i class="material-icons">person_add</i>
                            <?php echo e(__('Register')); ?>

                        </a>
                        <?php endif; ?>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <i class="material-icons">face</i>
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            
                            <?php if(Auth::user()->hasAnyRole(['administrator', 'journalist'])): ?> 
                            <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item">
                                Admin Panel
                            </a>
                            <?php endif; ?>

                            <?php if(!Auth::user()->hasAnyRole(['administrator', 'journalist'])): ?> 
                            <a href="<?php echo e(route('userPage', ['id'=>Auth::user()->id])); ?>" class="dropdown-item">
                                 My Profile
                            </a>
                            <?php endif; ?>

                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" 
                                method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>