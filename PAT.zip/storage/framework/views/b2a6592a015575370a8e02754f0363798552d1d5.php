<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>
<?php $__env->startSection('nav-class', 'navbar bg-light fixed-top navbar-expand-lg'); ?>


<?php $__env->startSection('content'); ?>




<div id="contactUsMap" class="big-map" style="z-index: -4"></div>
  <div class="main main-raised">
    <div class="contact-content">
      <div class="container">
        <h2 class="title">Send us a message!</h2>
        <div class="row">
          <div class="col-md-6">
            <p class="description">
              You can contact us with 
              anything related to PAT. 
              We&apos;ll get in touch with you 
              as soon as possible.
              <br>
              <br>
            </p>


            <?php if(isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              Thank you, your message has been sent!
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          
          <form action="<?php echo e(url('contact')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="name" class="bmd-label-floating">
                  Your name
                </label>
                <input type="text" class="form-control" id="name" name="name">
              </div>
              <div class="form-group">
                <label for="exampleInputEmails" class="bmd-label-floating">
                  Email address
                </label>
                <input type="email" class="form-control" id="exampleInputEmails" name="email">
                <span class="bmd-help">
                  We'll never share your email with anyone else.
                </span>
              </div>
              <div class="form-group">
                <label for="phone" class="bmd-label-floating">
                  Phone
                </label>
                <input type="text" class="form-control" id="phone" name="phone">
              </div>
              <div class="form-group label-floating">
                <label class="form-control-label bmd-label-floating" for="message_body"> 
                  Your message
                </label>
                <textarea class="form-control" rows="6" id="message_body" name="message_body"></textarea>
              </div>
              <div class="submit text-center">
                <input type="submit" class="btn btn-primary btn-raised btn-round" value="Contact Us">
              </div>
            </form>

            
          </div>
          <div class="col-md-4 ml-auto">
            <div class="info info-horizontal">
              
            </div> 
            <div class="info info-horizontal">
              <div class="icon icon-primary">
                <i class="material-icons">phone</i>
              </div>
              <div class="description">
                <h4 class="info-title">Give us a ring</h4>
                <p> PTCIJ
                  <br> +234.810.419.8112
                </p>
              </div>
            </div>
           <div class="info info-horizontal"> 
               
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
      $(document).ready(function() {
        nonBelievers.contactUsMap(
          "contactUsMap", 
          9.060892, 
          7.4637899, 
          15, 
          "PTCIJ Main Office"
        );
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>