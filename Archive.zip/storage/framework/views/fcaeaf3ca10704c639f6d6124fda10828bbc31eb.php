<?php $__env->startSection('body-class', 'contact-page sidebar-collapse'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header header-filter header-small" data-parallax="true">
    <div class="container">
      <div class="row justify-content-around">
       <?php $__env->startComponent('components.reports.metrics', ['report'=>$report]); ?>
           
       <?php echo $__env->renderComponent(); ?>
      </div>
      <div class="row">
        <div class="col col-md-8 ml-auto mr-auto text-center">
          <h2 class="title"><?php echo e($report->title); ?></h2>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">
          <!-- Tabs with icons on Card -->
          <div class="card card-nav-tabs">
            <div class="card-header card-header-primary">
              <!-- colors: "header-primary", "header-info", "header-success", "header-warning", "header-danger" -->
              <div class="nav-tabs-navigation">
                <div class="nav-tabs-wrapper">
                  <ul class="nav nav-tabs" data-tabs="tabs">
                    <li class="nav-item">
                      <a class="nav-link active show" href="#report" data-toggle="tab">
                        <i class="material-icons">face</i> Report
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#evidence" data-toggle="tab">
                        <i class="material-icons">chat</i> Evidence
                      <div class="ripple-container"></div></a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="#stories" data-toggle="tab">
                        <i class="material-icons">build</i> Related Stories
                      <div class="ripple-container"></div></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="card-body" style="min-height: 100px;">
              <div class="tab-content text-center">
                <div class="tab-pane active show" id="report">
                 
                  <div class="row">
                    <div class="col-8">
                      <blockquote class="blockquote my-2">
                          <?php echo $report->description; ?>

                      </blockquote>
                    </div>
                    <div class="col">
                      <?php $__env->startComponent('components.reports.details', ['report' => $report]); ?>
                          
                      <?php echo $__env->renderComponent(); ?>
                    </div>
                  </div>
                
                </div>
                <div class="tab-pane" id="evidence">
                
                  <?php $__env->startComponent('components.reports.evidence', ['report' => $report]); ?>
                      
                  <?php echo $__env->renderComponent(); ?>
                
                </div>
                <div class="tab-pane" id="stories">
                 
                  <?php $__env->startComponent('components.reports.stories', ['report' => $report]); ?>
                      
                  <?php echo $__env->renderComponent(); ?>

                </div>
              </div>
            </div>
          </div>
          <!-- End Tabs with icons on Card -->
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>