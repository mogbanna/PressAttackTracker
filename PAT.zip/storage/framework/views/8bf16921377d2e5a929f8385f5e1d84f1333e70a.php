<?php
    $evidences = App\Evidence::where('report_id', $report->id)->orderBy('created_at', 'desc')->get();
?>


<div class="row">

    <?php for($i = 0; $i < count($evidences); $i++): ?>

    <?php
        $evidence = $evidences[$i];
        $date = $evidence->created_at->format('d/m/Y');
    ?>

<div class="col-lg-3 col-sm-4">
        <div class="card card-profile card-plain">
            <div class="card-avatar">
                <img class="img" src="<?php echo e(asset('storage/'.$evidence->url)); ?>">
            </div>
            <div class="card-header mt-4">
                <a href="<?php echo e(asset('storage/'.$evidence->url)); ?>" download class="btn btn-info btn-round btn-sm">Download</a>
                <h6 class="card-category text-gray"><b>ID:</b> <?php echo e($evidence->id); ?>,  File Type:</b> <?php echo e($evidence->file_format); ?></h6>
                <h5 class="card-title"><b>Added:</b> <?php echo e($date); ?></h5>
            </div>
        </div>
    </div>

    <?php endfor; ?>
</div>




    







