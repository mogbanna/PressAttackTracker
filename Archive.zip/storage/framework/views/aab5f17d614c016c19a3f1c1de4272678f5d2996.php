<div class="card">
    <div class="card-header card-header-info card-header-icon">
        <div class="card-icon">
            <i class="material-icons">
                list_alt
            </i>
        </div>
        <h4 class="card-title">
            story Details
        </h4>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <th></th>
                <th></th>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <b>Status: </b>
                    </td>
                    <td>
                        <?php echo e(App\Status::select('name')->where(
                                'id', 
                                $story->status_id
                            )->first()->name); ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve', $story)): ?>
                        <?php if($story->status_id == 2): ?>
                        <a href="<?php echo e(route('adminApproveStory', ['id'=>$story->id])); ?>" 
                            class="btn btn-info btn-sm">
                            Approve
                        </a> 
                        <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Tags: </b>
                    </td>
                    <td>
                        <input type="text" value="<?php echo e($story->tags); ?>" name="tags" class="form-control tagsinput" 
                            data-role="tagsinput" data-color="danger" disabled>
                    </td>
                </tr>
                <tr>
                    <td>
                        <b>Related Report: </b>
                    </td>
                    <td>
                        <a href="<?php echo e(route('showReport', ['id'=>$story->report_id])); ?>">
                            <?php echo e(App\Report::select('title')->where('id', $story->report_id)->first()->title); ?>

                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>