<?php $__env->startSection('body-class', 'profile-page sidebar-collapse'); ?>


<?php $__env->startSection('content'); ?>
    
<div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('/img/city-profile.jpg')); ?>');"></div>
  <div class="main main-raised">
    <div class="profile-content">
      <div class="container">
        <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <div class="profile">
              <div class="avatar">
                <img src="<?php echo e(asset('/img/faces/christian.jpg')); ?>" alt="Circle Image" class="img-raised rounded-circle img-fluid">
              </div>
              <div class="name">
              <h3 class="title"><?php echo e($user->name); ?></h3>
              </div>
            </div>
          </div>
        </div>
        <div class="description text-center">
            <a href="<?php echo e(route('addReportForm')); ?>" class="btn btn-lg btn-danger justify-content-end">
                <i class="material-icons pr-2">create</i>
                Submit Report
            </a>
        </div>
        <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <div class="profile-tabs">
              <ul class="nav nav-pills nav-pills-icons justify-content-center" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" href="#userEditProfile" role="tab" data-toggle="tab">
                    <i class="material-icons">edit</i> Edit Profile
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#userProfileReports" role="tab" data-toggle="tab">
                    <i class="material-icons">palette</i> Submitted Reports
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="tab-content tab-space">
          <div class="tab-pane active text-center gallery" id="userEditProfile">
            
          </div>
          <div class="tab-pane text-center gallery" id="userProfileReports">
                  <?php $__env->startComponent('components.user.reports', ['reports' => Auth::user()->reports]); ?>
                      
                  <?php echo $__env->renderComponent(); ?>
              </div>
              
          </div>
        </div>
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>