<?php
$stories = App\Story::select()->where([
  ['report_id', $report->id],
  ['status_id', '3'],
  ])->get();
?>
<div class="row">
<?php for($i = 0; $i < count($stories); $i++): ?>

<?php
    $story = $stories[$i];
    $description = $story->story;
          $len = strLen($description);
          
          if($len > 100){
            $description = substr($story->story, 0, 100).'...' ;
          }
?>

<div class="col-lg-3 col-sm-4">
  <div class="card card-blog">
    <div class="card-header card-header-image">
      <a href="<?php echo e(route('story', ['id' => $story->id])); ?>">
          <img class="card-img-top" 
          src="<?php echo e(asset('storage/'.$story->thumbnail)); ?>" alt="card image cap">
      </a>
      <div class="colored-shadow" style="background-image: url( <?php echo e(asset('/img/examples/color3.jpg')); ?> ); opacity: 1;"></div>
    </div>
    <div class="card-body">
      <h4 class="card-title">
        <a href="<?php echo e(route('story', ['id' => $story->id])); ?>"><?php echo e($story->title); ?></a>
      </h4>
      <p class="card-description">
        <?php echo $description; ?>

        <br>
        <a class="text-info" href="<?php echo e(route('story', ['id' => $story->id])); ?>"> <b>Read More </b></a>
      </p>
    </div>
  </div>
</div>
<?php endfor; ?>
</div>