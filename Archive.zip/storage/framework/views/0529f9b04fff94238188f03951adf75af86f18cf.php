<?php
    $evidences = App\Evidence::orderBy('created_at', 'desc')->get();
?>
<div class="content">
    <table class="table table-striped">
        <thead>
            <th>Id</th>
            <th>Type</th>
            <th>Created At</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php for($i = 0; $i < count($evidences); $i++): ?>
            <?php
                $evidence = $evidences[$i];
            ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td>
                    <?php echo e($evidence->file_format); ?>

                </td>
                <td><?php echo e($evidence->created_at); ?></td>
                <td>
                    <a href="<?php echo e(asset('storage/'.$evidence->url)); ?>" download>
                        <i class="fa fa-download"></i>
                    </a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $evidence)): ?>
                    <a href="<?php echo e(route('adminDeleteEvidence', ['id'=>$evidence->id])); ?>" >
                        <i class="fa fa-times"></i>
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endfor; ?>
        </tbody>
    </table>
</div>