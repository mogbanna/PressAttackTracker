<?php $__env->startSection('content'); ?>

  <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo e(asset('img/bg3.jpg')); ?>')">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto">
          <div class="brand text-center">
            <h1 class="title">Press Attack Tracker</h1>
            <h3 class="description text-center">
  
              Records of journalists in Nigeria who have been mistreated.
              
            </h3>
          </div>
        </div>
      </div>



      <div class="row text-center my-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header card-header-text card-header-info">
                  <div class="card-text">
                    <h2 class="card-title"><?php echo e(App\Report::count()); ?> </h2>
                  </div>
                </div>
                <div class="display-4 card-description text-center my-2">
                  Total Reports
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header card-header-text card-header-primary">
                  <div class="card-text">
                  <h2 class="card-title"><?php echo e(App\Status::withCount('reports')->where('name', 'Verified')->first()->reports_count); ?> </h2>
                  </div>
                </div>
                <div class="display-4 card-description text-center my-2">
                  Verified Reports
                </div>
            </div>
        </div>
        <div class="col-md-4">
          <div class="card">
              <div class="card-header card-header-text card-header-danger">
                <div class="card-text">
                  <h2 class="card-title"><?php echo e(App\ReportType::withCount('reports')->where('name', 'Physical Attack')->first()->reports_count); ?> </h2>
                </div>
              </div>
              <div class="display-4 card-description text-center my-2">
                Violent Reports
              </div>
          </div>
        </div>
    </div>
    
    <div class="row justify-content-md-center">
        <div class="col col-lg-2">
            
          </div>
          <div class="col-md-auto">
          <a href="<?php echo e(route('reports', ['flag' => true])); ?>" class="btn btn-lg btn-info justify-content-end mr-4">
                  <i class="material-icons pr-2">search</i>
                  Browse Reports
          </a>
              <a href="<?php echo e(route('addReportForm')); ?>" class="btn btn-lg btn-danger justify-content-end">
                  <i class="material-icons pr-2">create</i>
                  Submit Reports
              </a>
              
          </div>
          <div class="col col-lg-2">
            
          </div>



        
    </div>
    <br>
  </div>
  </div>



<div class="main main-raised">
  <div class="container">
      
    <div class="section text-center">
      <div class="container">
        <div class="section">
            <h3 class="title text-center">Featured Story</h3>

          <div class="row">
            <div class="col-md-12">

              <?php
                  $featured = App\Story::orderBy('views', 'desc')->first();

                  $stories = App\Story::inRandomOrder()->limit(3)->get();
                  

              ?>

              <?php if($featured): ?>
    

              <div class="card card-raised card-background" style="background-image: url(' <?php echo e(asset('storage/'.$featured->thumbnail)); ?> ')">
                <div class="card-body">
                <h6 class="card-category text-info">Author: <?php echo e($featured->author); ?></h6>
                  <h3 class="card-title"><?php echo e($featured->title); ?></h3>

                  <?php
                      $description = $featured->story;

                      if(strLen($featured->story) > 100){
                        $description = substr($featured->story, 0, 100).'...';
                      }


                  ?>

                  <p class="card-description">
                      <?php echo $description; ?>

                  
                  <a href="<?php echo e(route('story',['id' => $featured->id])); ?>" class="btn btn-info btn-round btn-sm">
                    <i class="material-icons">subject</i> Read Report Story
                  </a>
                </p>
                </div>
              </div>
              <?php endif; ?>



            </div>
          </div>
        </div>
          <div class="section section-gray px-5">
            <h3 class="title text-center">Read The Latest Stories</h3>
            <div class="row justify-content-center">

              <?php for($i = 0; $i < count($stories); $i++): ?>
                  
              
              <?php
                  $story = $stories[$i];

                  $desctiption = $story->story;
                    if(strLen($description) > 100){
                      $description = substr($story->story, 0, 100).'... ';
                    }
                    
              ?>
              
              <div class="col-md-4">
                <div class="card card-blog">
                  <div class="card-header card-header-image">
                    <a href="<?php echo e(route('story',['id' => $story->id])); ?>">
                      <img class="img img-raised" src="<?php echo e(asset('storage/'.$story->thumbnail)); ?>">
                    </a>
                    <div class="colored-shadow" style="background-image: url( <?php echo e(asset('/img/examples/color3.jpg')); ?> ); opacity: 1;"></div>
                  </div>
                  <div class="card-body">
                    <h4 class="card-title">
                      <a href="<?php echo e(route('story',['id' => $story->id])); ?>">
                        <?php echo e($story->title); ?>

                      </a>
                    </h4>
                    <p class="card-description">
                     <?php echo $description; ?>

                      <a href="<?php echo e(route('story',['id' => $story->id])); ?>"> Read More </a>
                    </p>
                  </div>
                </div>
              </div>
          <?php endfor; ?>

            </div>
          </div>
        </div>
    </div>
</div>



<hr> 
  

<div class="social-line social-line-big-icons social-line-white ">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-2 col-4">
                <a href="https://twitter.com/PremiumTimesng" class="btn btn-link btn-just-icon btn-twitter">
                    <i class="fa fa-twitter"></i>
                </a>
            </div>
            <div class="col-md-2 col-4">
                <a href="https://www.facebook.com/Premiumtimes/" class="btn btn-link btn-just-icon btn-facebook">
                    <i class="fa fa-facebook-square"></i>
                </a>
            </div>
            
            <div class="col-md-2 col-4">
                <a href="#pablo" class="btn btn-link btn-just-icon btn-youtube">
                    <i class="fa fa-youtube-play"></i>
                </a>
            </div>
            <div class="col-md-2 col-4">
                <a href="#pablo" class="btn btn-link btn-just-icon btn-instagram">
                    <i class="fa fa-instagram"></i>
                </a>
            </div>
        </div>
    </div>
</div>
  

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>