<?php $__env->startSection('body-class', 'login-page sidebar-collapse'); ?>
<?php $__env->startSection('nav-class', 'navbar bg-light fixed-top navbar-expand-lg'); ?>


<?php $__env->startSection('content'); ?>



<div class="page-header header-filter" style="background-image: url('<?php echo e(asset('img/bg7.jpg')); ?>'); background-size: cover; background-position: top center;">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 ml-auto mr-auto">
          <div class="card card-login">
            <form class="form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

              <div class="card-header card-header-primary text-center">
                <h4 class="card-title"><?php echo e(__('Login')); ?></h4>
                <div class="social-line">
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-facebook-square"></i>
                  </a>
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-twitter"></i>
                  </a>
                  <a href="#pablo" class="btn btn-just-icon btn-link">
                    <i class="fa fa-google-plus"></i>
                  </a>
                </div>
              </div>
              <p class="description text-center">Or Be Classical</p>
                <div class="card-body">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="material-icons">mail</i>
                            </span>
                        </div>
                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                            <i class="material-icons">lock_outline</i>
                            </span>
                        </div>
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <!-- If you want to add a checkbox to this form, uncomment this code -->

                    <div class="checkbox ml-5">
                        <label>
                            <input class="form-check-input" type="checkbox" name="remember" 
                                id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <?php echo e(__('Remember Me')); ?>

                        </label>
                    </div> 
                </div>
                <div class="footer text-center">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Login')); ?>

                    </button>

                    <a class="btn btn-link text-dark" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php $__env->startSection('footer-display'); ?>

    <?php $__env->stopSection(); ?>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>